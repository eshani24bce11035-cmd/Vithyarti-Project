package edu.ccrm.service;

import edu.ccrm.domain.Grade;
import edu.ccrm.domain.Student;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;


public class StudentServiceImpl implements StudentService {

  
    private final Map<String, Student> byId = new LinkedHashMap<>();

    
    public Student addStudent(String regNo, String name, String email) {
        Student s = new Student(regNo, name, email);
        byId.put(s.getId(), s);
        
        return s;
    }

    
    public List<Student> getAllStudents() {
        
        return new ArrayList<>(byId.values());
    }

    
    public Optional<Student> findStudentById(String id) {
        // could also throw if not found, but Optional feels nicer
        return Optional.ofNullable(byId.get(id));
    }

    @Override
    public boolean assignGrade(String studentId, String courseCode, Grade grade) {
        Student s = byId.get(studentId);
        if (s == null) {
            // TODO: maybe log? Or even throw an exception instead of just false?
            return false;
        }
        // right now we allow overwriting grades (last one wins)
        s.assignGrade(courseCode, grade);
        return true;
    }

    // --- possible future ideas ---
    // public boolean removeStudent(String id) { ... }
    // public void clearAll() { byId.clear(); }
}