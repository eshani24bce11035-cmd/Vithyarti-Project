package edu.ccrm.service;

import edu.ccrm.domain.Grade;
import edu.ccrm.domain.Student;

import java.util.List;
import java.util.Optional;

// service interface for working with Student objects
// Note: might split into smaller services later (e.g. GradeService)
public interface StudentService {
    
    // adds a new student and returns it (UUID is generated internally)
    Student addStudent(String regNo, String name, String email);

    // returns all students (might get huge in memory, but fine for now)
    List<Student> getAllStudents();

    // look up student by ID (UUID)
    Optional<Student> findStudentById(String id);

    // assign grade for a student in a course
    boolean assignGrade(String studentId, String courseCode, Grade grade);

    // TODO: maybe add removeStudent or updateStudent later
    // Student removeStudent(String id);  <-- not sure yet if needed
}