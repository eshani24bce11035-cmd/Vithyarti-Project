package edu.ccrm.cli;

import edu.ccrm.domain.Grade;
import edu.ccrm.domain.Student;
import edu.ccrm.io.BackupService;
import edu.ccrm.io.ImportExportService;
import edu.ccrm.service.StudentService;
import edu.ccrm.service.StudentServiceImpl;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class CCRMApplication {

    
    private static final Scanner input = new Scanner(System.in);

    
    private static final StudentService studentSvc = new StudentServiceImpl();
    private static final ImportExportService importExportSvc = new ImportExportService();
    private static final BackupService backupSvc = new BackupService();

    public static void main(String[] args) {
        System.out.println("Welcome to Campus Course & Records Manager (CCRM)");
        loadInitialData();

        while (true) {
            showMenu();
            try {
                String line = input.nextLine();
                if (line.isBlank()) {
                    System.out.println("Please enter something...");
                    continue;
                }
                int choice = Integer.parseInt(line.trim());
                handleChoice(choice);
            } catch (NumberFormatException ex) {
                System.out.println("Invalid input. Please type a number.");
            } catch (Exception ex) {
                
                System.err.println("Unexpected error: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
    }

    private static void loadInitialData() {
        try {
            importExportSvc.importStudents(studentSvc);
            System.out.println("Initial data loaded (if any file was present).");
        } catch (Exception e) {
            
            System.err.println("Couldn’t load initial data: " + e.getMessage());
        }
    }

    private static void showMenu() {
        System.out.println();
        System.out.println("==== CCRM Menu ====");
        System.out.println("1. Add Student");
        System.out.println("2. List Students");
        System.out.println("3. View Student Transcript");
        System.out.println("4. Assign Grade");
        System.out.println("5. Export Data");
        System.out.println("6. Create Backup");
        System.out.println("7. Platform Info");
        System.out.println("0. Exit");
        System.out.print("Enter choice: ");
    }

    private static void handleChoice(int option) {
        switch (option) {
            case 1: addStudentFlow(); break;
            case 2: listStudentsFlow(); break;
            case 3: transcriptFlow(); break;
            case 4: gradeAssignFlow(); break;
            case 5: exportFlow(); break;
            case 6: backupFlow(); break;
            case 7: platformInfo(); break;
            case 0:
                exportFlow();  
                System.out.println("Bye 👋");
                System.exit(0);
            default:
                System.out.println("Unknown option, please try again.");
        }
    }

    private static void addStudentFlow() {
        System.out.print("Registration Number: ");
        String regNo = input.nextLine().trim();

        System.out.print("Name: ");
        String name = input.nextLine().trim();

        System.out.print("Email: ");
        String email = input.nextLine().trim();

        Student newStudent = studentSvc.addStudent(regNo, name, email);
        System.out.println("Student added (ID: " + newStudent.getId() + ")");
    }

    private static void listStudentsFlow() {
        List<Student> students = studentSvc.getAllStudents();
        if (students.size() == 0) {   
            System.out.println("No students found.");
            return;
        }
        System.out.println("Students:");
        for (Student st : students) {
            
            System.out.println("- " + st.getProfileDetails());
        }
    }

    private static void transcriptFlow() {
        System.out.print("Student ID: ");
        String id = input.nextLine().trim();

        Optional<Student> found = studentSvc.findStudentById(id);
        if (!found.isPresent()) {
            System.out.println("Student not found.");
            return;
        }
        Student s = found.get();
        System.out.println(s.generateTranscript());
    }

    private static void gradeAssignFlow() {
        System.out.print("Student ID: ");
        String id = input.nextLine().trim();

        System.out.print("Course Code (e.g., CS101): ");
        String course = input.nextLine().trim();

        System.out.print("Grade (S/A/B/C/D/F): ");
        String g = input.nextLine().trim().toUpperCase();

        try {
            Grade grade = Grade.valueOf(g);
            boolean success = studentSvc.assignGrade(id, course, grade);
            if (success) {
                System.out.println("Grade assigned.");
            } else {
                System.out.println("Failed to assign grade (check student ID?).");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid grade value. Try S/A/B/C/D/F.");
        }
    }

    private static void exportFlow() {
        try {
            importExportSvc.exportStudents(studentSvc);
            System.out.println("Data exported.");
        } catch (Exception e) {
            System.err.println("Export failed: " + e.getMessage());
        }
    }

    private static void backupFlow() {
        try {
            backupSvc.createBackup();
            System.out.println("Backup created.");
        } catch (Exception e) {
            System.err.println("Backup failed: " + e.getMessage());
        }
    }

    private static void platformInfo() {
        
        System.out.println("Java version: " + System.getProperty("java.version"));
        System.out.println("OS: " + System.getProperty("os.name") + " " + System.getProperty("os.version"));
    }
}