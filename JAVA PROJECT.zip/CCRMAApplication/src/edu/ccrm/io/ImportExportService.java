package edu.ccrm.io;

import edu.ccrm.domain.Grade;
import edu.ccrm.domain.Student;
import edu.ccrm.service.StudentService;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

/**
 * Simple CSV import/export in project directory under data/students.csv
 *
 * CSV format:
 *   id,regNo,name,email,course1:GRADE|course2:GRADE|...
 *
 * NOTE: id is regenerated on import to avoid conflicts. (yeah, kind of lossy…)
 */
public class ImportExportService {

    private final Path dataDir = Path.of("data"); // TODO: maybe make configurable
    private final Path csvFile = dataDir.resolve("students.csv");

    /**
     * Reads students from CSV and populates service.
     * Current design: IDs are re-generated every time (so it's not a strict "restore").
     */
    public void importStudents(StudentService service) throws IOException {
        if (!Files.exists(csvFile)) {
            // nothing to import, just bail silently
            return;
        }
        try (BufferedReader br = Files.newBufferedReader(csvFile)) {
            String line;
            while ((line = br.readLine()) != null) {
                // Skip header if present
                if (line.startsWith("id,regNo,name,email,courses")) continue;

                // split into 5 parts max (id,regNo,name,email,courses)
                String[] parts = line.split(",", 5);
                if (parts.length < 4) continue; // meh, invalid line

                String regNo = parts[1].trim();
                String name = parts[2].trim();
                String email = parts[3].trim();
                String courses = parts.length == 5 ? parts[4].trim() : "";

                Student s = service.addStudent(regNo, name, email);

                // parse courses if any
                if (!courses.isEmpty()) {
                    String[] entries = courses.split("\\|");
                    for (String entry : entries) {
                        if (entry.isBlank()) continue;
                        String[] kv = entry.split(":");
                        if (kv.length != 2) continue; // malformed
                        String course = kv[0].trim();
                        String gradeStr = kv[1].trim();
                        try {
                            Grade g = Grade.valueOf(gradeStr);
                            service.assignGrade(s.getId(), course, g);
                        } catch (IllegalArgumentException ignored) {
                            // bad grade code, just skip (maybe log later?)
                        }
                    }
                }
            }
        }
    }

    /**
     * Writes all students to CSV (overwrites existing file).
     */
    public void exportStudents(StudentService service) throws IOException {
        if (!Files.exists(dataDir)) {
            Files.createDirectories(dataDir);
        }
        try (BufferedWriter bw = Files.newBufferedWriter(csvFile)) {
            // header row
            bw.write("id,regNo,name,email,courses");
            bw.newLine();

            for (Student s : service.getAllStudents()) {
                // serialize courses into course:GRADE|course2:GRADE...
                StringBuilder courses = new StringBuilder();
                for (Map.Entry<String, Grade> e : s.getGrades().entrySet()) {
                    if (courses.length() > 0) courses.append("|");
                    courses.append(e.getKey()).append(":").append(e.getValue().name());
                }

                // TODO: consider proper CSV lib, this manual escaping feels brittle
                bw.write(String.join(",",
                        s.getId(),
                        escape(s.getRegNo()),
                        escape(s.getName()),
                        escape(s.getEmail()),
                        courses.toString()
                ));
                bw.newLine();
            }
        }
    }

    // CSV escaping: minimal version (quotes things with commas, quotes, or newlines)
    private String escape(String s) {
        if (s == null) return "";
        String v = s.replace("\"", "\"\""); // escape quotes
        if (v.contains(",") || v.contains("\"") || v.contains("\n")) {
            return "\"" + v + "\"";
        }
        return v;
    }
}