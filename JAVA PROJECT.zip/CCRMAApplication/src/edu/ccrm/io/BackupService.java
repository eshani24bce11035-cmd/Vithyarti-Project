package edu.ccrm.io;

import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Creates a timestamped copy of data/students.csv into backups/ folder.
 * 
 * Note: This is pretty naive, but good enough for now.
 */
public class BackupService {

    private final Path dataCsv = Path.of("data", "students.csv");
    private final Path backupDir = Path.of("backups");

    public void createBackup() throws IOException {
        if (!Files.exists(dataCsv)) {
            // Nothing to backup... but let's still ensure the backup dir exists
            if (!Files.exists(backupDir)) {
                Files.createDirectories(backupDir);
            }
            System.out.println("No data file found, nothing backed up.");  // little console hint
            return;
        }

        if (!Files.exists(backupDir)) {
            Files.createDirectories(backupDir);  // maybe cache this later
        }

        // format timestamp like 2025-09-25_13-45-12 (easier to read)
        String ts = LocalDateTime.now().format(
                DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")
        );

        Path backupFile = backupDir.resolve("students_" + ts + ".csv");

        // note: won't overwrite if file already exists (could append a counter later if needed)
        Files.copy(dataCsv, backupFile, StandardCopyOption.COPY_ATTRIBUTES);

        // just to be chatty
        System.out.println("Backup created at: " + backupFile.toAbsolutePath());
    }

    // maybe add a "listBackups" method here later
}