package edu.ccrm.domain;

import java.util.*;   
import java.util.UUID;

public class Student {
    private final String id;     
    private String regNo;
    private String name;
    private String email;

    
    private final Map<String, Grade> gradeBook = new LinkedHashMap<>();

    public Student(String regNo, String name, String email) {
        this.id = UUID.randomUUID().toString();  // could also use shorter IDs later
        this.regNo = regNo;
        this.name = name;
        this.email = email;
    }

    // getters & setters - generated, but I kept them anyway
    public String getId() {
        return id;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String nm) {   // note: param name shortened just for variety
        this.name = nm;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String mail) {
        this.email = mail;
    }

    // Returns an unmodifiable copy, just in case
    public Map<String, Grade> getGrades() {
        return Collections.unmodifiableMap(gradeBook);
    }

    // assign grade for a course
    public void assignGrade(String courseCode, Grade grade) {
        // TODO: maybe validate courseCode format later
        gradeBook.put(courseCode, grade);
    }

    // short profile string - mostly for debugging / console display
    public String getProfileDetails() {
        return String.format("ID=%s, RegNo=%s, Name=%s, Email=%s, Courses=%d",
                id, regNo, name, email, gradeBook.size());
    }

    public String generateTranscript() {
        StringBuilder sb = new StringBuilder();
        sb.append("===== Transcript =====\n");
        sb.append("ID: ").append(id).append("\n");
        sb.append("RegNo: ").append(regNo).append("\n");
        sb.append("Name: ").append(name).append("\n");
        sb.append("Email: ").append(email).append("\n");
        sb.append("----------------------\n");

        if (gradeBook.isEmpty()) {
            sb.append("No courses/grades available.\n");
        } else {
            double total = 0.0;
            int count = 0;
            // could replace with streams, but loop feels easier to debug
            for (Map.Entry<String, Grade> entry : gradeBook.entrySet()) {
                sb.append(entry.getKey()).append(": ")
                        .append(entry.getValue()).append("\n");
                total += entry.getValue().toGPA();
                count++;
            }
            // calculate GPA
            double gpa = (count > 0) ? (total / count) : 0.0;
            sb.append("----------------------\n");
            sb.append(String.format("GPA: %.2f\n", gpa));
        }

        sb.append("======================\n");
        return sb.toString();
    }

    // maybe: add equals/hashCode later if needed for collections
    // @Override public boolean equals(Object o) { ... }
}