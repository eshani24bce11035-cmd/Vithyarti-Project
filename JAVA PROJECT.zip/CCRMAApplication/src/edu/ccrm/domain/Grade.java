package edu.ccrm.domain;


public enum Grade {
    S, A, B, C, D, F;

    
    public double toGPA() {
        
        switch (this) {
            case S:
                return 10.0; 
            case A:
                return 9.0;
            case B:
                return 8.0;
            case C:
                return 7.0;
            case D:
                return 6.0;
            case F:
                return 0.0; 
            default:
                
                return -1.0;
        }
    }

    
}
